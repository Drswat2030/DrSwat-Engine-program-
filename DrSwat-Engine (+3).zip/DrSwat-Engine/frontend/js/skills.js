fetch('/skills')
  .then(res => res.json())
  .then(data => {
    // Display skills
  });

function loadSkillDetail(id) {
  fetch(`/skills/${id}`)
    .then(res => res.json())
    .then(skill => {
      // Display skill detail
    });
}
